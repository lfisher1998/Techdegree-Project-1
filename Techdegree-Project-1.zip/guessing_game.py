
#Python Web Development Techdegree
#Project 1 - Number Guessing Game
#--------------------------------
#


import random


def start_game():
    print("Welcome to the Number Guessing Game, player!")
    
    correct_number = random.randint(1,10)
    number_of_guesses = 1
    high_score = 1
    
    
    random_number_guess = int(input("Please enter a number between and including 1-10: "))
    while random_number_guess != int(correct_number):
        if random_number_guess > int(correct_number):
            random_number_guess = int(input("Too high! Guess lower! Please try again: "))
            number_of_guesses += 1
            continue
        elif random_number_guess < correct_number:
            random_number_guess = int(input("Too low! Guess higher! Please try again: "))
            number_of_guesses += 1
            continue
        
    print("Congrats! You guessed correctly! It took you a total number of {} guesses.".format(number_of_guesses))

            
            
            
            
            
#"""Psuedo-code Hints
#    
#    When the program starts, we want to:
#    ------------------------------------
#    2. Store a random number as the answer/solution.
#    3. Continuously prompt the player for a guess.
#      a. If the guess greater than the solution, display to the player "It's lower".
#      b. If the guess is less than the solution, display to the player "It's higher".
#    
#    4. Once the guess is correct, stop looping, inform the user they "Got it"
#         and show how many attempts it took them to get the correct number.
#    5. Let the player know the game is ending, or something that indicates the game is over.
#    
#    ( You can add more features/enhancements if you'd like to. )
#    """
#    # write your code inside this function.
#    
#    #Display an intro/welcome message to the player    


if __name__ == '__main__':
    # Kick off the program by calling the start_game function.
    start_game()
              
    